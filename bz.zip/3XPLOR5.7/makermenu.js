const makermenu = (prefix) => { 
	return ` 
╭───「 *CREATOR MENU* 」───
│
├➲ *${prefix}sticker*
├➲ *${prefix}quotemaker [tx/wtrmk/tema]*
├➲ *${prefix}nulis [nama/kelas/text]*
├➲ *${prefix}trigger [reply image]*
├➲ *${prefix}rip [reply image]*
├➲ *${prefix}wasted [reply image]*
├➲ *${prefix}cphlogo [Fadhil/Graphy]*
├➲ *${prefix}cglitch [Fadhil/Graphy]*
├➲ *${prefix}cpubg [Fadhil/Graphy]*
├➲ *${prefix}cml [Salsa/Fadhil]*
├➲ *${prefix}tahta [Fadhil]*
├➲ *${prefix}croman [Fadhil dan Salsa]*
├➲ *${prefix}cthunder [Fadhil]*
├➲ *${prefix}cbpink [Fadhil]*
├➲ *${prefix}cmwolf [Fadhil]*
├➲ *${prefix}csky [Fadhil]*
├➲ *${prefix}cwooden [Fadhil]*
├➲ *${prefix}cflower [Fadhil]*
├➲ *${prefix}clove [Fadhil]*
├➲ *${prefix}ccrossfire [Fadhil]*
├➲ *${prefix}cnaruto [Fadhil]*
├➲ *${prefix}cparty [Fadhil]*
├➲ *${prefix}cshadow [Fadhil]*
├➲ *${prefix}cminion [Fadhil]*
├➲ *${prefix}cneon [Fadhil]*
├➲ *${prefix}cneon2 [Fadhil]*
├➲ *${prefix}cneongreen [Fadhil]*
├➲ *${prefix}c3d [Fadhil]*
├➲ *${prefix}csky [Fadhil]*
├➲ *${prefix}tts [id Fadhil]*
├➲ *${prefix}ttp [Fadhil]*
├➲ *${prefix}slide [Fadhil]*
├➲ *${prefix}stiker*
├➲ *${prefix}gifstiker*
├➲ *${prefix}toimg*
├➲ *${prefix}img2url*
├➲ *${prefix}nobg*
├➲ *${prefix}tomp3*
├➲ *${prefix}ocr*
│
╰──────────────────────

	           *©explors*`
	}
exports.makermenu = makermenu